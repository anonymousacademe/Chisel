import vtracer, cairosvg, io, os, re
import numpy as np
from PIL import Image, ImageFilter
from scipy import ndimage
SRC='/root/.claude/uploads/56c17f5d-d72f-5774-ac2a-667a83c682e3/0253f490-image.png'
BG=(244,243,235); S=2048
src=Image.open(SRC).convert('RGB')
big=src.resize((S,S),Image.LANCZOS)
a=np.array(big).astype(float)
lum=a.mean(2)
# ink color estimate
inkcore=lum<70
INK=tuple(int(v) for v in np.median(a[inkcore],axis=0))
# --- ink layer: smooth mask
core=lum<69
raw=(lum<125)&ndimage.binary_dilation(core,iterations=3)
m=Image.fromarray((raw*255).astype('uint8')).filter(ImageFilter.GaussianBlur(2.2))
ink=(np.array(m)>127)
Image.fromarray((~ink*255).astype('uint8')).convert('RGB').save('ink.png')
# --- fill layer: inpaint generous ink zone with nearest outside colors
wide=ndimage.binary_dilation(raw, iterations=4)
_,idx=ndimage.distance_transform_edt(wide,return_indices=True)
f=a[idx[0],idx[1]]
fim=Image.fromarray(f.astype('uint8')).filter(ImageFilter.MedianFilter(7))
fa=np.array(fim).astype(int); mx=fa.max(2); mn=fa.min(2)
fa[(mn>=228)&((mx-mn)<=12)]=BG
Image.fromarray(fa.astype('uint8')).save('fill.png')
vtracer.convert_image_to_svg_py('fill.png','fill.svg',colormode='color',hierarchical='stacked',mode='spline',filter_speckle=16,color_precision=8,layer_difference=2,corner_threshold=60,length_threshold=4.0,max_iterations=10,splice_threshold=45,path_precision=2)
vtracer.convert_image_to_svg_py('ink.png','ink.svg',colormode='binary',mode='spline',filter_speckle=8,corner_threshold=60,length_threshold=4.0,max_iterations=10,splice_threshold=45,path_precision=2)
def body(p):
    s=open(p).read(); return s[s.index('>',s.index('<svg'))+1:s.rindex('</svg>')]
inkb=body('ink.svg')
inkhex='#%02X%02X%02X'%INK
inkb=re.sub(r'fill="#[0-9A-Fa-f]{6}"',f'fill="{inkhex}"',inkb)
def build(bg=True):
    inner=(body('fill.svg') if bg else strip_bg(body('fill.svg')))+inkb
    if not bg:
        return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" width="1024" height="1024">'+inner+'</svg>'
    clip='<defs><clipPath id="sq"><rect width="2048" height="2048" rx="400"/></clipPath></defs>'
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2048 2048" width="1024" height="1024">'
            +clip+'<g clip-path="url(#sq)">'+inner+'</g></svg>')
def strip_bg(b):
    # drop paths filled with the background color
    return re.sub(r'<path[^>]*/>','',b,count=1)
open('chisel-icon.svg','w').write(build())
open('chisel-mark.svg','w').write(build(bg=False))
print('INK',INK, os.path.getsize('chisel-icon.svg'), os.path.getsize('chisel-mark.svg'))
png=cairosvg.svg2png(url='chisel-icon.svg',output_width=S,output_height=S)
r=Image.open(io.BytesIO(png)).convert('RGBA')
w=Image.new('RGBA',(S,S),'white'); w.alpha_composite(r); w=w.convert('RGB')
c=Image.new('RGB',(2048,1024)); c.paste(src,(0,0)); c.paste(w.resize((1024,1024),Image.LANCZOS),(1024,0)); c.save('cmp2.png')
box=(800,600,1400,1200)
c=Image.new('RGB',(1200,600)); c.paste(big.crop(box),(0,0)); c.paste(w.crop(box),(600,0)); c.save('crop2.png')
